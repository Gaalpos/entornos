package EJ02Testing;

public class Pendulo {
    
}
