#!/bin/bash

echo "Introduce una palabra"
read palabra
echo "Introduce un numero"
read numero

for (( i=0; i<$numero; i=i+1 ))
do
echo "$palabra" >> archivo.txt
done
