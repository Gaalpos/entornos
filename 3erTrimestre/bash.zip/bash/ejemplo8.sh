#!/bin/bash

profes[0]="Angel"
profes[1]="Miguel"

frutas=("pera" "limon" 44)

echo "El segundo profe es ${profes[1]}"
echo "El array vale ${profes[*]}"

for elemento in ${frutas[*]}
do
	echo $elemento
done

echo "tenemos ${#frutas[*]} frutas"

profes[2]="Bea"
profes[3]="Pepe"
unset profes[1]

for elemento in ${profes[*]} 
do
        echo $elemento
done

ficheros=( `ls`)
echo "${ficheros[10]}"
