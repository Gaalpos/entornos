#!/bin/bash

expr 3 + 2

echo`expr 2 + 5

num=6
let resultado=num+5
echo `resultado`
