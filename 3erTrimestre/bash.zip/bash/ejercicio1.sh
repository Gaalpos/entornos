#!/bin/bash

num=9

#suma 2 a la variable num y muestra el resultado por pantalla

resultado=`expr $num + 2`
let resultado=num+2
resultado=$((num+2))
resultado=$[num+2]

echo $resultado 
