#!/bin/bash

#esto es un comentario monolinea

: 'esto es un comentario
de varias lineas'

valor=1

echo $valor
echo "date"
echo 'date'
echo `date`
