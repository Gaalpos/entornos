#!/bin/bash

if [ $1 -lt 0 ]
then
echo "Es negativo"
exit 0
fi
echo "Es positivo"
