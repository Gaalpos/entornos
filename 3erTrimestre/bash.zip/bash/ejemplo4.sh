#!/bin/bash

decimal=3
#decimal=$[ decimal/2 ]
decimal=$(echo "scale=3;$decimal/2" | bc) 
echo $decimal

echo "Inserta tu nombre"
read nombre
echo "Hola $nombre, eres un pesao"

read -p "Inserta tu nombre: " nombre
echo " Pero $nombre"

read -n 1 -p  "Contesta s/n:" condicion
echo -e "\n\tHas pulsado: $condicion"

if [[ "$concicion" == "s" ]]; then
	 echo "has pulsado sí"
elseif [ "$condicion" == "n" ]
then
	echo "has pulsado no"
else
	echo "has pulsado otra cosa"
fi
 
