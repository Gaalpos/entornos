#!/bin/bash

#Pide la edad de una persona por teclado y muestra si es mayor de edad
#Controla que no introduzcan edades negativas ni mayor de 120, mostrando un error

read -p "Introduce edad" $edad


if [ $edad -le 0 -o $edad -gt 120 ]; then
	echo "Edad incorrecta"
	exit 1
fi

if [ $edad -ge 18 ]; then
	echo "Eres mayor de edad"
else
	echo "Eres menor de edad"
fi

