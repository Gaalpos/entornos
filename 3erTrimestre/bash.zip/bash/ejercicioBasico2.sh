#!/bin/bash

valor1=16
valor2=9

echo $valor2

let max=$valor1

if [ $valor2 > $max ]
then
max=$valor1
fi

echo $max



