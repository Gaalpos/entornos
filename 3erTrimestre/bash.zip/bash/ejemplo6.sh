#!/bin/bash

borrar(){
                fichero = hola
                if [ ! -f $fichero ] ; then
                        echo "no existe el fichero" 
                        exit 1
                fi
                if [ ! -w $fichero ] ; then
                        echo "no puedes borrarlo, no tienes permisos"
                        exit 1
                fi
                rm $fichero
                echo "fichero borrado correctamente"

}

opcion=x

while [ "$opcion" != "s" ]
do

echo "pulsa l para listar"
echo "pulsa b para borrar"
echo "pulsa c para crear"
echo "pulsa s para salir"
read  -n 1 -p "Inserta la opción" option

case $option in
	s)
		exit 0
	;;
	l)
		ls
	;;
	b)
		borrar
	;;
	c)
		touch hola
		echo "fichero creado correctamente"
	;;
	*)
		echo "opción incorrecta"
	;;
esac

done
