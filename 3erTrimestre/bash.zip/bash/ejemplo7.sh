#!/bin/bash

echo "Me has pasado $# parametros"

if [ $#  -lt 3 ]
then
	echo "Numero de parametros incorrecto"
	exit 1
fi

echo "El segundo parametro es $2"
echo "El tercer parametro es $3"

case $1 in
	suma)
		let suma=$2+$3
		echo "La suma vale $suma"
	;;
	resta)
		let resta=$2-$3
		echo "La resta vale $resta"
	;;
	producto)
		let producto=$2\*$3
		echo "El producto vale $producto"
	;;
	division)
		if [ $3 -eq 0 ]
		then
		echo "ERROR division por cero"
		exit 1
		fi
		division=$( echo "scale=3; $2/$3" | bc -l )
		echo "La division vale $division"
	;;
	*)
	echo "Operador invalido"
	exit 0
esac
