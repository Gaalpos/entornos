#!/bin/bash

bitcoin=28507

opcion=0

pasarABitcoins(){
	read -p "Inserta euros " euros
	bitcoins=$( echo "scale=8; $euros/28565" | bc -l)
	echo "$euros euros son $bitcoins bit"
}
pasarAEuros(){
	read -p=$( echo "scale=8; $bitcoins*28565" | bc -l)
	echo "$bitcoins bts son $euros euros"
}

while [ $opcion -ne 3 ] 
do

	echo "1 a bitcoin, 2 a fiat, 3 salir"
	read -n 1 -p "opcion: " opcion
	case $opcion in
		1)
			pasarABitcoins
		;;
		2)
			pasarAEuros
		;;
		3)
		exit 0
		;;
		*) echo "opcion incorrecta"
	esac
done
