#!/bin/bash

for nombre in angel bea pepe
do
	echo$nombre
done 

for fichero in `ls`
do
	echo $fichero
done

for i in {1..50}
do
	echo $i
done

for i in {1..50..10}
do
	echo $i
done
