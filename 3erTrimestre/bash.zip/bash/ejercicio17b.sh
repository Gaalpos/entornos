 #!/bin/bash

bitcoin=28507

opcion=0

pasarABitcoins(){
	euros=$1
	bitcoins=$( echo "scale=8; $euros/28565" | bc -l)
	echo "$euros euros son $bitcoins bit"
	return $bitcoins
}
pasarAEuros(){
	bitcoins=$1
	euros=$( echo "scale=8; $bitcoins*28565" | bc -l)
	echo "$bitcoins bts son $euros euros"
}

while [ $opcion -ne 3 ]
do

	echo "1 a bitcoin, 2 a fiat, 3 salir"
	read -n 1 -p "opcion: " opcion
	case $opcion in
		1)
			echo ""
			read -p "inserta euros" euros
			bitcoins =$( pasarABitcoins $euros )
			echo"$euros euros son $bitcoins bts"
		;;
		2)
			echo ""
			read -p "inserta bitcoins" bitcoins
			pasarAEuros $bitcoins
		;;
		3)
		exit 0
		;;
		*) echo "opcion incorrecta"
	esac
done
