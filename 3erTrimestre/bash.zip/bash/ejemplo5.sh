#!/bin/bash

valor=5
if [$valor > 0 ]
then
	echo "Es positivo"
fi

if test $valor > 0; then
echo "Es positivo"
fi

mensaje=hola
if [ -z "$mensaje" ]; then
	echo "La variable no está vacía"
fi

if [ -f "$mensaje" ]; then
        echo "Es un fichero"
fi
