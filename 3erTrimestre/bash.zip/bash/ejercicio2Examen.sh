#!/bin/bash

borrar(){
                if [ -f examen.txt ] ; then
			rm -r examen.txt
                        echo "La carpeta ya existía y la he borrado"
                fi

}

crear(){
	borrar
	mkdir datos
	cd datos
	touch examen.txt
	echo $opcion/2 >> examen.txt
}

while [ $opcion != 0 ]
do

read  -n 1 -p "Inserta la opción" opcion

if [[ $opcion -lt 0 ]]
then
	crear

elseif [[ $opcion > 0 ]]
then
	n=$opcion
	while [ n > 0 ]
	do
	echo "$n"
	n=$n-1
else
	echo "Fin"
	exit 0
fi

